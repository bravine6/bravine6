<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\dashboard\cl1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>