<?php $__env->startSection('content'); ?>
        <h1><?php echo e($title); ?> </h1>
  <p>  this is the abou page </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\cl1\resources\views/pages/about.blade.php ENDPATH**/ ?>