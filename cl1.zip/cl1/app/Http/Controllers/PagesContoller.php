<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesContoller extends Controller
{
    public function index(){
        $title='Welcome to UNIAIR';
      // return view('pages.index');
        return view('pages.index')->with('title',$title);
    }
    public function about(){
        $title='About us';
        return view('pages.about')->with('title',$title);
      // return view('pages.about', compact('title'));
    }
    public function services(){
        $data = array(
            'title'=>'Services',
       'services'=>['Writing Posts','A flair for the dramatic','Enthuastic readers']     
        );
        return view('pages.services')->with($data);
    }
    public function welcome(){
        return view('welcome');
    }
}
