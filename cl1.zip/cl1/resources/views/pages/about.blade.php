@extends('layout.app')
@section('content')
        <h1>{{$title}} </h1>
  <p>  this is the abou page </p>
@endsection
